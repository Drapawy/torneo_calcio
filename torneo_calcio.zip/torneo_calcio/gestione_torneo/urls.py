# gestione_torneo/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('risultati/<int:categoria_id>/', views.risultati, name='risultati'),
    path('classifiche/<int:categoria_id>/', views.classifiche, name='classifiche'),
]
