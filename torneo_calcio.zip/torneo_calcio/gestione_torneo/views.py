# gestione_torneo/views.py

from django.shortcuts import render, get_object_or_404
from .models import Partita, Squadra, Categoria
from django.db.models import Q

def home(request):
    categorie = Categoria.objects.all()
    return render(request, 'home.html', {'categorie': categorie})

def risultati(request, categoria_id):
    categoria = get_object_or_404(Categoria, id=categoria_id)
    partite = Partita.objects.filter(categoria=categoria).order_by('-data')
    return render(request, 'risultati.html', {'partite': partite, 'categoria': categoria})

def classifiche(request, categoria_id):
    categoria = get_object_or_404(Categoria, id=categoria_id)
    squadre = Squadra.objects.filter(categoria=categoria)
    classifica = []

    for squadra in squadre:
        partite_giocate = Partita.objects.filter(
            Q(squadra_casa=squadra) | Q(squadra_ospite=squadra),
            categoria=categoria,
            gol_casa__isnull=False,
            gol_ospite__isnull=False
        )

        # Inizializzazione delle statistiche
        punti = 0
        gol_fatti = 0
        gol_subiti = 0
        vittorie = 0
        pareggi = 0
        sconfitte = 0

        for partita in partite_giocate:
            if partita.squadra_casa == squadra:
                gol_pro = partita.gol_casa
                gol_contro = partita.gol_ospite
            else:
                gol_pro = partita.gol_ospite
                gol_contro = partita.gol_casa

            gol_fatti += gol_pro
            gol_subiti += gol_contro

            if gol_pro > gol_contro:
                punti += 3
                vittorie += 1
            elif gol_pro == gol_contro:
                punti += 1
                pareggi += 1
            else:
                sconfitte += 1

        differenza_reti = gol_fatti - gol_subiti
        partite_giocate_count = vittorie + pareggi + sconfitte

        classifica.append({
            'squadra': squadra,
            'punti': punti,
            'giocate': partite_giocate_count,
            'vittorie': vittorie,
            'pareggi': pareggi,
            'sconfitte': sconfitte,
            'gol_fatti': gol_fatti,
            'gol_subiti': gol_subiti,
            'differenza_reti': differenza_reti,
        })

    # Ordina la classifica
    classifica.sort(key=lambda x: (x['punti'], x['differenza_reti'], x['gol_fatti']), reverse=True)

    return render(request, 'classifiche.html', {'classifica': classifica, 'categoria': categoria})
