from django.contrib import admin
from django import forms
from .models import Categoria, Formato, Squadra, Partita

class PartitaForm(forms.ModelForm):
    class Meta:
        model = Partita
        fields = '__all__'

class PartitaAdmin(admin.ModelAdmin):
    form = PartitaForm
    list_display = ('squadra_casa', 'squadra_ospite', 'categoria', 'data', 'gol_casa', 'gol_ospite')
    list_filter = ('categoria',)
    search_fields = ('squadra_casa__nome', 'squadra_ospite__nome')
    autocomplete_fields = ['squadra_casa', 'squadra_ospite']

class SquadraAdmin(admin.ModelAdmin):
    list_display = ('nome', 'categoria')
    list_filter = ('categoria',)
    search_fields = ('nome',)

admin.site.register(Categoria)
admin.site.register(Formato)
admin.site.register(Squadra, SquadraAdmin)
admin.site.register(Partita, PartitaAdmin)
