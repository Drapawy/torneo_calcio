from django.db import models

# gestione_torneo/models.py

from django.db import models

class Categoria(models.Model):
    nome = models.CharField(max_length=50)

    def __str__(self):
        return self.nome

class Formato(models.Model):
    descrizione = models.CharField(max_length=50)
    giocatori_in_campo = models.IntegerField()

    def __str__(self):
        return self.descrizione

class Squadra(models.Model):
    nome = models.CharField(max_length=100)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)

    def __str__(self):
        return self.nome

class Partita(models.Model):
    squadra_casa = models.ForeignKey(Squadra, related_name='partite_casa', on_delete=models.CASCADE)
    squadra_ospite = models.ForeignKey(Squadra, related_name='partite_ospite', on_delete=models.CASCADE)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)
    formato = models.ForeignKey(Formato, on_delete=models.CASCADE)
    data = models.DateTimeField()
    gol_casa = models.PositiveIntegerField(null=True, blank=True)
    gol_ospite = models.PositiveIntegerField(null=True, blank=True)

    def __str__(self):
        return f"{self.squadra_casa} vs {self.squadra_ospite} - {self.data.strftime('%d/%m/%Y')}"
