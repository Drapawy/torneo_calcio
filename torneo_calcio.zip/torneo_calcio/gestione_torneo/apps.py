from django.apps import AppConfig


class GestioneTorneoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gestione_torneo'
