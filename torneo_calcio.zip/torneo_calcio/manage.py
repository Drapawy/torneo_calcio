# manage.py

#!/usr/bin/env python
"""Utility per la gestione del progetto Django."""
import os
import sys

def main():
    """Esegue le operazioni amministrative."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'torneo_calcio.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Non è possibile importare Django. Assicurati che sia installato e "
            "che sia disponibile nel tuo PYTHONPATH."
        ) from exc
    execute_from_command_line(sys.argv)

if __name__ == '__main__':
    main()
