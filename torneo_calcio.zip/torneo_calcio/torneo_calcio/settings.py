# torneo_calcio/settings.py

import os
from pathlib import Path

# Percorso base del progetto
BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'chiave-segreta-del-tuo-progetto'

DEBUG = True

ALLOWED_HOSTS = ['AcsiWebMaster.pythonanywhere.com']

INSTALLED_APPS = [
    # App di Django predefinite
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',        # Aggiunto
    'django.contrib.messages',        # Aggiunto
    'django.contrib.staticfiles',
    # La tua app
    'gestione_torneo',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',      # Aggiunto
    'django.middleware.common.CommonMiddleware',                 # Aggiunto
    'django.middleware.csrf.CsrfViewMiddleware',                 # Aggiunto
    'django.contrib.auth.middleware.AuthenticationMiddleware',   # Aggiunto
    'django.contrib.messages.middleware.MessageMiddleware',      # Aggiunto
    'django.middleware.clickjacking.XFrameOptionsMiddleware',    # Aggiunto
]

ROOT_URLCONF = 'torneo_calcio.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'gestione_torneo', 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                # Processori di contesto predefiniti
                'django.template.context_processors.debug',
                'django.template.context_processors.request',          # Aggiunto
                'django.contrib.auth.context_processors.auth',         # Aggiunto
                'django.template.context_processors.i18n',
                'django.template.context_processors.media',
                'django.template.context_processors.static',
                'django.template.context_processors.tz',
                'django.contrib.messages.context_processors.messages', # Aggiunto
            ],
        },
    },
]

WSGI_APPLICATION = 'torneo_calcio.wsgi.application'

# Configurazione del database (usa SQLite per semplicità)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Configurazioni internazionali
LANGUAGE_CODE = 'it-it'

TIME_ZONE = 'Europe/Rome'

USE_I18N = True

USE_L10N = True    # Assicurati che sia presente

USE_TZ = True

# Configurazione dei file statici
STATIC_URL = '/static/'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
